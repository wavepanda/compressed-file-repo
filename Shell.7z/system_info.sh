echo -e "\n/////////////////////  checking system info ///////////////////////\n"
cat /etc/redhat-release && \
cat /proc/cpuinfo|grep cores;cat /proc/cpuinfo|grep MHz|sed -n 1p && \
cat /proc/meminfo|grep MemTotal;cat /proc/meminfo |grep MemFree
