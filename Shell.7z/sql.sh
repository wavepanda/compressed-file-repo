#!/bin/bash
yum install mariadb-server -y && \
systemctl start mariadb
mysql –u root –p && \
alter user 'root'@'localhost' identified by 'Newuser1'; && \
flush privileges;